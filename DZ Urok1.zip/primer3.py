n = int(input("введите любое число"))
cislo = str(n)
c1 = cislo + cislo
c2 = cislo + cislo + cislo
sum = n + int(c1) + int(c2)
print("Значение:", sum)
