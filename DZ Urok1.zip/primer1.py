ravno1 = 10 + 1
print(ravno1)
ravno2 = 10 + 7
print(ravno2)
age = int(input("введите ваш возраст"))
print(age)
name = input("введите ваше имя")
print(name)
zp = int(input("сколько хочешь зарабатывать?"))
print(zp)
work = input( ;"какую должность хочешь занимать?")
print(work)
