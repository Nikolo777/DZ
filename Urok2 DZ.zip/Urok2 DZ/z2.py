items = input ("Укажите значения через запятятую >>> ").split(",")
max_idx = len(items) - 1