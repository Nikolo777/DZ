month = int (input("Укажите месяц под его порядковым номером >>> " ))
year_dict = {
    "зима" : (12, 1, 2),
    "весна" : (3, 4, 5),
    "лето" : (6, 7, 8),
    "осень" : (9, 10, 11),
}
for season, monthe in year_dict.items():
    if month in months:
        print(f"Время года = {season}")
