with open('DZ55.txt', 'r') as my_file:
    my_dict = {}
    for line in my_file.readlines():
        info = line.split()
        time = 0
        for i in info:
            if i.isdigit():
                time += int(i)
        my_dict.update({info[0][:-1]: time})
    print(my_dict)