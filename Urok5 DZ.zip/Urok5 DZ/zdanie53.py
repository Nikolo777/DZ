with open("workers_list.txt", "r") as file:
    workers = [line.split() for line in file.readlines()]

workers_dict = [{"name": elem[0], "salary": float(elem[1])} for elem in workers]

for el in workers_dict:
    if el['salary'] < 20000:
        print(f"У сотрудника по фамилии {el['name']} оклад менее 20 тыс. руб.")

sum_salary = 0

for el in workers_dict:
    sum_salary = sum_salary + el['salary']

print(f"Средняя зарплата всех сотрудников = {round(sum_salary / 10)}")
