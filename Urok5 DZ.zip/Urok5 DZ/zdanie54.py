change = {"One": "Раз", "Two": "Два", "Three": "Три", "Four": "Читыре"}

new_data = []

with open("one-two.txt") as start_file:
    for line in start_file.readlines():
        word, digit = line.split(' - ')
        new_data.append(f"{change[word]} - {digit}")

with open("raz-dva.txt", "w") as final_file:
    final_file.writelines(new_data)
