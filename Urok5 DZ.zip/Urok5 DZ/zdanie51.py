string = []
while True:
    with open('task01.txt','a+') as f:
        string = input("введите строку >>> ")

        if not string:
            break
        f.write (f"{string}\n")