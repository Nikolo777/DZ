import json

with open('DZ56_1.txt', 'r') as my_file:
    my_dict = {}
    sum_profit = 0
    n = 0
    for line in my_file.readlines():
        info = line.split()
        profit = float(info[2]) - float(info[3])
        if profit > 0:
            sum_profit += profit
            n += 1
        my_dict.update({info[0]: profit})
    avr_profit = sum_profit / n
    my_dict.update({"average_profit": avr_profit})
    with open('HW06.json', 'w') as new_file:
        json.dump(my_dict, new_file)
