def generate_user_info(
        name=input('Введите имя: '),
        surname=input('Введите фамилию: '),
        year=input('Введите год рождения: '),
        city=input('Введите город: '),
        email=input('Введите email: '),
        phone=input('Введите номер телефона: ')):
    return f'{name} {surname} {year} {city} {email} {phone}'


print('Информация о пользователе:', generate_user_info())
