def my_func(num_1, num_2, num_3):
    nums = [num_1, num_2, num_3]
    nums.sort()
    return nums[1] + nums[2]


print(my_func(98, 2, 6))

