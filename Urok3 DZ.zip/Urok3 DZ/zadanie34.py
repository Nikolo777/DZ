def my_func(x, y):
    if x and y:
        result = 1
        for i in range(abs(y)):
            result *= x
        return f'Результат возведения в степень: {1 / result}'
    else:
        return 'Ошибка ввода.'


def is_pos_float(user_str):
    try:
        x = float(user_str)
    except ValueError:
        return
    if x > 0:
        return x


def is_neg_int(user_str):
    try:
        x = int(user_str)
    except ValueError:
        return
    if x < 0:
        return x


print(
    my_func(
        is_pos_float(input("Введите действительное положительное число: ")),
        is_neg_int(input("Введите целое отрицательное число: "))))