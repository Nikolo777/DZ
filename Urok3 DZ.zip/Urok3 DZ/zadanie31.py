ef division(num_1, num_2):
    try:
        result = round(float(num_1) / float(num_2), 2)
        return result
    except ValueError:
        return 'введены некорректные значения.'
    except ZeroDivisionError:
        return 'на ноль делить нельзя.'


first_user_number = input("Введите, пожалуйста, число №1: ")
second_user_number = input("Введите, пожалуйста, число №2: ")

print(f'Результат деления: {division(first_user_number, second_user_number)}')