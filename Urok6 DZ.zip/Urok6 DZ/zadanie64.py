class Car:
    speed: float
    color: str
    name: str
    is_police: bool

    def __init__(self, speed: float, color: str, name: str, is_police: bool):
        self.speed = speed
        self.color = color
        self.name = name
        self.is_police = is_police

    def go(self):
        return f"Машина {self.name} поехала"

    def stop(self):
        return f"Машина {self.name} остановилась"

    def turn(self, direction: str):
        return f"Машина {self.name} повернула {direction}"

    def show_speed(self):
        return f"Текущая скорость машины {self.name} составляет {self.speed} км/ч"


class TownCar(Car):
    def show_speed(self):
        if self.speed > 60:
            return f"Машина {self.name} превышает допустимую срокость в 60 км/ч, текущая скорость {self.speed} км/ч"
        else:
            return f"Текущая скорость машины {self.name} составляет {self.speed} км/ч"


class SportCar(Car):
    is_sport: bool

    def __init__(self, speed: float, color: str, name: str, is_police = False, is_sport = True):
        super().__init__(speed, color, name, is_police)
        self.is_sport = is_sport


class WorkCar(Car):
    def show_speed(self):
        if self.speed > 40:
            return f"Машина {self.name} превышает допустимую срокость в 40 км/ч, текущая скорость {self.speed} км/ч"
        else:
            return f"Текущая скорость машины {self.name} составляет {self.speed} км/ч"


class PoliceCar(Car):
    is_police = True


town_car = TownCar(44, "red", "mazda", False)
sport_car = SportCar(100, "green", "Ferrari", False)
work_car = WorkCar(50, "grey", "volvo", False)
police_car = PoliceCar(70, "white", "lada", True)

print(town_car.go())
print(town_car.show_speed())
print(work_car.go())
print(work_car.show_speed())
print(work_car.stop())
print(sport_car.turn('налево'))
print(police_car.go())
