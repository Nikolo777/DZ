class Stationary:
    title: str

    def start_draw(self):
        print(f"Запуск отрисовки")


class Pen(Stationary):
    def start_draw(self):
        print(f"Запуск отрисовки ручкой")


class Pencil(Stationary):
    def start_draw(self):
        print(f"Запуск отрисовким карандашом")


class Handle(Stationary):
    def start_draw(self):
        print(f"Запуск отрисовки маркером")


stationary = Stationary()
pen = Pen()
pencil = Pencil()
handle = Handle()

stationary.start_draw()
pen.start_draw()
handle.start_draw()
