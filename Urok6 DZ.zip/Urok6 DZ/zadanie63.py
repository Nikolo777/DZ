class Worker:
    name: str
    surname: str
    position: str
    _income: dict

    def __init__(self, name: str, surname: str, position: str, wage: int, bonus: int):
        self.name = name
        self.surname = surname
        self.position = position
        self._income = {"wage": wage, "bonus": bonus}

    def get_total_income(self):
        return self._income["wage"] + self._income["bonus"]


class Position(Worker):

    def __init__(self, name: str, surname: str, position: str, wage: int, bonus: int):
        super().__init__(name, surname, position, wage, bonus)

    def get_full_name(self):
        return f"{self.name} {self.surname}"


worker1 = Position("John", "Do", "worker", 150000, 25000)
print(worker1.get_full_name())
print(f"Доход с учетом премии = {worker1.get_total_income()}")
